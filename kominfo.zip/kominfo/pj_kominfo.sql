-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Des 2021 pada 06.47
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pj_kominfo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `judul`, `tanggal`, `isi`) VALUES
(1, 'Gunung semeru', '2021-12-01', 'Rosella Wardani merupakan seorang penyintas bencana awan panas Gunung Semeru. Perempuan asal Dusun Curah Kobokan, Desa Supiturang, Kecamatan Pronojiwo, Kabupaten Lumajang itu memilih menjadi relawan untuk melupakan trauma yang dialaminya.\r\n\r\nArtikel ini telah tayang di Kompas.com dengan judul \"Kisah Korban Erupsi Gunung Semeru, Pilih Jadi Relawan untuk Hilangkan Rasa Ketakutan\", Klik untuk baca: https://regional.kompas.com/read/2021/12/15/132333078/kisah'),
(2, 'Gunung ijen', '2021-12-10', 'Gunung Ijen adalah sebuah gunung berapi yang terletak di perbatasan Kabupaten Banyuwangi dan Kabupaten Bondowoso, Jawa Timur, Indonesia. Gunung ini memiliki ketinggian 2.386 mdpl dan terletak berdampingan dengan Gunung Merapi'),
(5, 'youtobe', '2021-12-26', 'okaoskaoks');

-- --------------------------------------------------------

--
-- Struktur dari tabel `corousel_content`
--

CREATE TABLE `corousel_content` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `corousel_content`
--

INSERT INTO `corousel_content` (`id`, `name`, `tag`, `gambar`) VALUES
(11, 'kominfo', 'bwi', 'Kominfo.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `role`) VALUES
(0, 'ozy', '$2y$10$uNewk5o.hK/qTKoZ/4QKZOUgkGuF40zrd1tL6YUm.oa7aoo2FBFSS', 'ozy@gmail.com', 'admin'),
(6, 'ozy2', '$2y$10$7py0mDRXYoSy1KpGVvx.nOtb5blFvYHw2eDgT4/4gicYfOZW0/sCO', 'ozy1@gmail.com', 'user'),
(7, 'boby', '$2y$10$e2PBY/mS6f1XCp7fHVEieuSVeNWrcEDwFl0oz2Esjy2K7pOOBm8Li', 'boby@gmail.com', 'user');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `corousel_content`
--
ALTER TABLE `corousel_content`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `corousel_content`
--
ALTER TABLE `corousel_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
