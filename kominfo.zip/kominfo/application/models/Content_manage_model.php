<?php
class content_manage_model extends CI_Model
{
    public function create($name, $tag, $image)
    {
        $data = [
            "name" => $name,
            "tag" => $tag,
            "gambar" => $image,
        ];
        $this->db->insert("corousel_content", $data);
    }
    public function get_all()
    {
        return $this->db->get("corousel_content")->result();
    }
    public function retrieve($id)
    {
        return $this->db->get_where("corousel_content", ["id" => $id])->row();
    }
    public function update($name, $tag, $id)
    {
        $data= ["name" => $name, "tag" => $tag];
        $this->db->update("corousel_content",$data, ["id" => $id]);
    }
}
