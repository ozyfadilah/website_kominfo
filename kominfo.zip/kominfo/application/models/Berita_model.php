<?php
class Berita_model extends CI_Model {
    public function ambil_semua() {
        $this->db->select();
        $this->db->from("berita");
        return $this->db->get()->result();
    }
    public function masuk($data){
        $this->db->insert("berita",$data);
    }
    public function retrieve($id)
    {
        return $this->db->get_where("berita", ["id" => $id])->row();
    }
    public function update($judul, $isi, $id)
    {
        $data= ["judul" => $judul, "isi" => $isi];
        $this->db->update("berita",$data, ["id" => $id]);
    }
}