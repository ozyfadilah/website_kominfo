<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("content_manage_model");
        $this->load->model('Berita_model','bemod');
    }
    public function index()
    {
        $data["carousel"]=$this->content_manage_model->get_all();
        $data["berita"] = $this->bemod->ambil_semua();
        $this->load->view("templates/welcome_header");
        $this->load->view("welcome_view",$data);
        $this->load->view("templates/welcome_footer");
    }
}
