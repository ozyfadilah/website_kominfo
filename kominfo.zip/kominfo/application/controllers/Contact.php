<?php
class Contact extends CI_Controller{
    public function index(){
        $this->load->view("templates/welcome_header");
        $this->load->view("view_contact");
        $this->load->view("templates/welcome_footer");
    }
}