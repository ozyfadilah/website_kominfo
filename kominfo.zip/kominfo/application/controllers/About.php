<?php
class About extends CI_Controller{
    public function index(){
        $this->load->view("templates/welcome_header");
        $this->load->view("view_about");
        $this->load->view("templates/welcome_footer");
    }
}