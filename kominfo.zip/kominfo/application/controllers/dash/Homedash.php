<?php
class Homedash extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        checkLogin("isLogin");
        $this->load->model("content_manage_model");
    }

    public function index()
    {
  
        $this->load->view("templates/home_header");
        $this->load->view("dash/home_view");
        $this->load->view("templates/home_footer");
    }
}
