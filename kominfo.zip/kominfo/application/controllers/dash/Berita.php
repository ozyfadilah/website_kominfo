<?php
class Berita extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Berita_model', 'bemod');
    }
    public function index()
    {
        $data["berita"] = $this->bemod->ambil_semua();
        $this->load->view("templates/home_header");
        $this->load->view("dash/berita_view", $data);
        $this->load->view("templates/home_footer");
    }
    public function add_view()
    {
        $this->load->view("templates/home_header");
        $this->load->view("dash/berita_action_view");
        $this->load->view("templates/home_footer");
    }
    public function action($type, $id = "")
    {
        $data["type"] = $type;
        if (strtolower($type) == "edit") {
            $data["berita"] = $this->berita_model->retrieve($id);
        }

        $this->load->view("templates/home_header");
        $this->load->view("dash/berita_action_view", $data);
        $this->load->view("templates/home_footer");
    }

    public function handler($type)
    {
        if ($type == "tambah") {
            $this->_tambah();
        } else {
            $this->_edit();
        }
    }
    public function _tambah(){
        $data=[
            "judul"=>$this->input->post("judul"),
            "isi"=>$this->input->post("isi"),
            "tanggal"=>date("y-m-d")
        ];
        $this->bemod->masuk($data);
        return redirect("/dash/berita");
    }
    private function _edit()
    {
        $judul=$this->input->post("judul");
        $id=$this->input->post("id");
        $isi=$this->input->post("isi");
        $tanggal=$this->input->date("y-m-d");
        $this->berita_model->update($judul,$isi,$id, $tanggal);
        redirect("dash/berita");
    }
    public function delete($id){
        $this->db->delete("berita",["id"=>$id]);
        redirect("dash/berita");
    }
}
