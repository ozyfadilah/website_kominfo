<?php
class Content_management extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("content_manage_model");
    }
    public function index()
    {
        $data["carousel"] = $this->content_manage_model->get_all();
        $this->load->view("templates/home_header");
        $this->load->view("dash/content_management_view", $data);
        $this->load->view("templates/home_footer");
    }
    public function action($type, $id = "")
    {
        $data["type"] = $type;
        if (strtolower($type) == "edit") {
            $data["carousel"] = $this->content_manage_model->retrieve($id);
        }

        $this->load->view("templates/home_header");
        $this->load->view("dash/content_management_action_view", $data);
        $this->load->view("templates/home_footer");
    }
    public function handler($type)
    {
        if ($type == "add") {
            $this->_add();
        } else {
            $this->_edit();
        }
    }
    private function _add()
    {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('tag', 'Tag', 'required');
        if ($this->form_validation->run() == FALSE) {
            $data["type"] = "ADD";
            $this->load->view("templates/home_header");
            $this->load->view("dash/content_management_action_view", $data);
            $this->load->view("templates/home_footer");
        } else {
            $name = $this->input->post("name");
            $tag = $this->input->post("tag");
            $config['upload_path']          = './assets/images/carousel';
            $config['allowed_types']        = 'gif|jpg|png';
            $config['max_size']             = 100;
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('image')) {
                $error = array('error' => $this->upload->display_errors());
            } else {
                $image = $this->upload->data();
                $this->content_manage_model->create($name, $tag, $image['file_name']);
                redirect(base_url("dash/content_management"));
            }
        }
    }
    private function _edit()
    {
        $name=$this->input->post("name");
        $id=$this->input->post("id");
        $tag=$this->input->post("tag");
        $this->content_manage_model->update($name,$tag,$id);
        redirect("dash/content_management");
    }
    public function delete($id){
        $this->db->delete("corousel_content",["id"=>$id]);
        redirect("dash/content_management");
    }
}
