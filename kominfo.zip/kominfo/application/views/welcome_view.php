<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php foreach ($carousel as $key => $value) : ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?= $key ?>"></li>
        <?php endforeach; ?>
    </ol>
    <div class="carousel-inner">
        <?php foreach ($carousel as $key => $value) : ?>
            <div class="carousel-item <?= $key == "0" ? "active" : "" ?>">
                <img height="400" src="<?= base_url("/assets/images/carousel/") . $value->gambar ?>" class="d-block w-100" alt="...">
            </div>
        <?php endforeach; ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
<div class="container-md mt-5">
    <div class="row ">
        <div class="col-3">
            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Profil</a>
                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Rangkuman Berita</a>
                <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Pengumuman</a>
                <a class="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">Settings</a>
            </div>
        </div>
        <div class="col-9">
            <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                  <?php foreach ($berita as $key ) :?>

                
                <h1><?= $key->judul?> </h1>
                 <p class = "text-justify"
                 ><?= $key->isi?></p>
                <?php endforeach ?>
                </div>
                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">ekqwejkaejk</div>
                <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">...</div>
                <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">...</div>
            </div>
        </div>
    </div>
    <div class="row d-flex justify-content-center">

        <div class="card mr-3" style="width: 10rem;">
            <img src="https://image.flaticon.com/icons/png/512/1232/1232643.png" class="card-img-top rounded-circle" alt="...">
            <div class="card-body">
                <p class="card-text"><h3>BERANDA</h3></p>
            </div>
        </div>
        <div class="card" style="width: 10rem;">
            <img src="https://image.flaticon.com/icons/png/512/1255/1255910.png" class="card-img-top rounded-circle" alt="...">
            <div class="card-body">
                <p class="card-text"><h3>PENGADUAN</h3></p>
            </div>
        </div>
        <div class="card ml-3" style="width: 10rem;">
            <img src="https://image.flaticon.com/icons/png/512/1221/1221943.png" class="card-img-top rounded-circle" alt="...">
            <div class="card-body">
                <p class="card-text"><h3>LAYANAN</h3></p>
            </div>
        </div>
        
    
    </div>
</div>