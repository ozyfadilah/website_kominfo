<img src="<?= base_url("assets/images/about/about_us-1.jpg") ?>" width="100%" height="100px">
<div class="shadow-sm p-3 mb-5 bg-white rounded container-sm mt-3">
    <h3 class="text-center mb-3">TENTANG KAMI</h3>
    <p class="text-center mb-5">Sekilas tentang Kominfo

 

Kementerian Komunikasi dan Informatika (sebelumnya bernama "Departemen Penerangan" (1945-1999), "Kementerian Negara Komunikasi dan Informasi" (2001-2005), dan Departemen Komunikasi dan Informatika (2005-2009), disingkat Depkominfo) adalah Departemen/kementerian dalam Pemerintah Indonesia yang membidangi urusan komunikasi dan informatika. Kementerian Kominfo dipimpin oleh seorang Menteri Komunikasi dan Informatika (Menkominfo) sejak tanggal 27 Oktober 2014.

Di Kabupaten Banyuwangi melalui Peraturan Daerah Kabupaten Banyuwangi Nomor 9, Tahun 2016 tentang Pembentukan dan Susunan Perangkat Daerah (Lembaran Daerah Kabupaten Banyuwangi Tahun 2016 Nomor 1 Seri C) terbentuklah Organisasi Perangkat Daerah, Dinas Komunikasi dan Informatika Kabupaten Banyuwangi (yang merupakan gabungan dari Bagian Pengelola Data Elektronik Setda Kabupaten Banyuwangi dan Dinas Perhubungan, Komunikasi dan Informatika Kabupaten Banyuwangi).

Kemudian terbit Peraturan Bupati Banyuwangi Nomor 31 Tahun 2016 Tentang Kedudukan, Susunan Organisasi, Tugas Dan Fungsi, Serta Tata Kerja  Dinas Komunikasi Dan Informatika      ( Berita Daerah Kabupaten Banyuwangi  Tahun 2016 Nomor  4  Seri  C), yang terdiri dari Sekretariat dengan 3 (tiga) Sub Bagian dan 4 (empat) Bidang dengan masing-masing 3 (tiga) Seksi.

Saat ini Kantor Dinas Komunikasi dan Informatika Kabupaten Banyuwangi berada di Jl. K.H. Agus Salim No.85, Taman Baru, Kec. Banyuwangi, Kabupaten Banyuwangi yang ditempati oleh Kepala Dinas, Sekretariat, Bidang Statistik Jl. K.H. Agus Salim No.85, Taman Baru, Kec. Banyuwangi, Kabupaten Banyuwangi

Kepala Dinas Komunikasi dan Informatika Kabupaten Banyuwangi di jabat oleh Budi Santoso      ).</p>
