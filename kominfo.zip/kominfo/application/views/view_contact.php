<img src="<?= base_url("assets/images/about/about_us-1.jpg") ?>" width="100%" height="100px">
<div class="shadow-sm p-3 mb-5 bg-white rounded container-sm mt-3">
    <h3 class="text-center mb-3">HUBUNGI KAMI</h3>
    <p class="text-center mb-5">Silakan hubungi kami untuk menemukan solusi seputar layanan Kementerian Komunikasi dan Informatika</p>

    <h3 class="text-center mb-5 text-primary">Kementrian Komunikasi dan Informatika</h3>

    <div class="container">
        <div class="row justify-content-md-left pl-5 mt-2">
            <div class="col-">
                <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="col-md-auto text-left">
                <h6>Alamat</h6>
                <label>Jl. K.H. Agus Salim No.85, Taman Baru, Kec. Banyuwangi, Kabupaten Banyuwangi, Jawa Timur 68416</label>
            </div>
        </div>
        <div class="row justify-content-md-left pl-5 mt-2">
            <div class="col-">
                <i class="fas fa-mobile-alt"></i>
            </div>
            <div class="col-md-auto text-left">
                <h6>Telepon</h6>
                <label>(0333)424972</label>
            </div>
        </div>
        <div class="row justify-content-md-left pl-5 mt-2">
            <div class="col-">
                <i class="fab fa-firefox"></i>
            </div>
            <div class="col-md-auto text-left">
                <h6>Website</h6>
                <label>diskominfo.banyuwangikab.go.id</label>
            </div>
        </div>
        <div class="row justify-content-md-left pl-5 mt-2">
            <div class="col-">
                <i class="fas fa-envelope-square"></i>
            </div>
            <div class="col-md-auto text-left">
                <h6>Email</h6>
                <label>diskominfobanyuwangi@gmail.com</label>
            </div>
        </div>
    </div>