<div class="container-fluid">
    <h3 class="page-title">ADD CONTENT</h3>
    <div class="panel" style="margin-top: 10px;">
        <div class="panel-heading">
            <h3 class="panel-title">Corousel content</h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <form  action="<?= base_url("/dash/berita/tambah")?>" method="post">
                        <div class="form-group">
                            <label for="judul">judul</label>
                            <input type="text" class="form-control" name="judul" id="name">
             
                        </div>
                        <div class="form-group">
                            <label for="tag">Isi</label>
                            <textarea name="isi" class="form-control" id="" cols="30" rows="10"></textarea>                           
                        </div>
                       
                      
                        <a class="btn btn-danger" href="<?= base_url("dash/berita") ?>">Back</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>