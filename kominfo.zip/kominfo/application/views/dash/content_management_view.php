<div class="container-fluid">
    <h3 class="page-title">Elements</h3>
    <a href="<?= base_url("dash/content_management/action/add") ?>" class="btn btn-primary">ADD CONTENT</a>
    <div class="panel" style="margin-top: 10px;">
        <div class="panel-heading">
            <h3 class="panel-title">Corousel content</h3>
        </div>
        <div class="panel-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Tag</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($carousel as $key => $item) : ?>
                        <tr>
                            <td><?= $key + 1 ?></td>
                            <td><img width="50" src="<?= base_url("assets/images/carousel/") . $item->gambar ?>" alt=""></td>
                            <td><?= $item->name ?></td>
                            <td><?= $item->tag ?></td>
                            <td><a href="<?= base_url("dash/content_management/action/edit/") . $item->id ?>">
                            EDIT</a> | <a href="<?= base_url("dash/content_management/delete/") . $item->id ?>">DELETE</a></td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

</div>