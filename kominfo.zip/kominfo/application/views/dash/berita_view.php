<div class="container-fluid">
    <h3 class="page-title">Elements</h3>
    <a href="<?= base_url("dash/berita/add_view") ?>" class="btn btn-primary">TAMBAH BERITA</a>
    <div class="panel" style="margin-top: 10px;">
        <div class="panel-heading">
            <h3 class="panel-title">Tabel Berita</h3>
        </div>
        <div class="panel-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Isi</th>
                        <th>Tanggal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($berita as $key ) :?>
                        <tr>
                             <td><?= $key->judul?></td>
                             <td><?= $key->isi?></td>
                             <td><?= $key->tanggal?></td>
                             <td><a href="<?= base_url("dash/berita/action/edit/") . $item->id ?>">
                             EDIT</a> |<a href="<?= base_url("dash/berita/delete/") . $item->id ?>"> HAPUS </a> </td>
                        </tr>
                        <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>