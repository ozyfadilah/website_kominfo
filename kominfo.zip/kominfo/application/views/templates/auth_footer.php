<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->

<script src="<?= base_url("/assets") ?>/bootstrap/js/popper.min.js"></script>
<script src="<?= base_url("/assets") ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url("/assets") ?>/js/my-login.js"></script>
<script>
	let base_url = "<?= base_url()  ?>";
</script>
<script src="<?= base_url("/assets") ?>/js/script.js"></script>
</body>

</html>