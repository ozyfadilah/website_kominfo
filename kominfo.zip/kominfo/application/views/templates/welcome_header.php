<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <script src="<?= base_url("/assets") ?>/bootstrap/js/jquerybuts.js"></script>
    <link rel="stylesheet" href="<?= base_url() ?>/assets/bootstrap/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/5b8537ef3f.js" crossorigin="anonymous"></script>
    <title>Login</title>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-md">
        <a class="navbar-brand" href="#">
        <img src="<?= base_url("assets/images/logo/kominfo.png") ?>" width="40" height="35" alt="KOMINFO"> KOMINFO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="<?= base_url() ?>">BERANDA <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url("/about") ?>">TENTANG KAMI</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url("/contact") ?>">HUBUNGI KAMI</a>
                </li>
            </ul>
            <a class="btn btn-primary" href="<?=base_url('login')?>" class="my-2 my-lg-0">
                Login
            </a>
        </div>
    </div>
</nav>